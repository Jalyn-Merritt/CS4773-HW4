package viewmodel;

public interface Observer {
	
	public void update(String teamName, int score, String modificationDate);
}